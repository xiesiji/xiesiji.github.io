import json, subprocess
from pathlib import Path
base=Path(__file__).resolve().parent
def call(*args, stdin=None):
    p=subprocess.run(['agent-browser','--session','little-roo',*map(str,args)],input=stdin,text=True,capture_output=True,check=True)
    return p.stdout
script=(base/'check-layout.js').read_text()
results=[]
for w,h in [(2100,900),(1512,837),(1440,900),(1024,768),(900,900),(768,1024),(810,1080),(390,844),(320,640),(844,390)]:
    call('set','viewport',w,h)
    r=json.loads(call('eval','--stdin',stdin=script))
    if isinstance(r,str):r=json.loads(r)
    results.append(r)
    failures=[x for x in r['records'] if x['overflow'] or not x['allButtons44'] or not x['imageLoaded'] or not x['validAlt'] or not x['textWithinReservedSpace'] or abs(x['ratio']-4/3)>.001]
    print(f'{w}x{h}: {len(failures)} issues, next visible on {sum(x["nextVisible"] for x in r["records"])}/9 pages',flush=True)
    if (w,h) in [(1512,837),(768,1024),(320,640),(844,390)]:
        call('screenshot',base/f'cover-{w}x{h}.png')
    if failures:print(json.dumps(failures),flush=True)
(base/'layout-results.json').write_text(json.dumps(results,indent=2))
assert all(r['font'] for r in results)
assert all(not p['overflow'] and p['allButtons44'] and p['imageLoaded'] and p['validAlt'] and p['textWithinReservedSpace'] and abs(p['ratio']-4/3)<.001 for r in results for p in r['records'])
print('90 page/viewport checks passed.')
