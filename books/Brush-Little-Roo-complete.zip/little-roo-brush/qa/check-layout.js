(async()=>{
  await document.fonts.ready;
  document.getElementById('restart').click();
  const records=[];
  for(let n=0;n<9;n++){
    const img=document.getElementById('art');await img.decode();
    await new Promise(requestAnimationFrame);
    const rect=id=>{const r=document.getElementById(id).getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height,bottom:r.bottom,right:r.right};};
    const page=rect('page'),words=rect('words'),next=rect('next');
    const controls=[...document.querySelectorAll('button')].filter(b=>b.getClientRects().length).map(b=>({label:b.getAttribute('aria-label')||b.textContent,w:b.getBoundingClientRect().width,h:b.getBoundingClientRect().height}));
    records.push({page:n+1,ratio:page.width/page.height,overflow:document.documentElement.scrollWidth>innerWidth,textWithinReservedSpace:words.bottom<=page.y+page.height*.24,allButtons44:controls.every(b=>b.w>=43.9&&b.h>=43.9),imageLoaded:img.naturalWidth===1448&&img.naturalHeight===1086,validAlt:!!img.alt&&img.alt!=='undefined',nextVisible:next.bottom<=innerHeight,documentHeight:document.documentElement.scrollHeight,pageBottom:page.bottom,wordSize:getComputedStyle(document.getElementById('words')).fontSize});
    if(n<8)document.getElementById('next').click();
  }
  document.getElementById('restart').click();
  return {viewport:[innerWidth,innerHeight],font:document.fonts.check('20px "Patrick Hand"'),records};
})();
