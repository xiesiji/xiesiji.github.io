(async()=>{
 const $=id=>document.getElementById(id),checks=[];
 const check=(name,condition)=>{checks.push({name,pass:!!condition});if(!condition)throw Error(name);};
 const click=id=>$(id).click();
 click('restart');check('Cover starts at page 1',$('counter').textContent==='1 / 9');
 check('Back disabled on cover',$('previous').disabled);
 click('tap');check('Cover illustration begins story',$('counter').textContent==='2 / 9');
 click('tap');check('Food interaction gives feedback',$('hint').textContent==='Crunch, crunch!');
 check('Interaction does not advance page',$('counter').textContent==='2 / 9');
 for(let i=0;i<4;i++)click('next');
 for(let i=0;i<3;i++)click('tap');
 check('Brushing feedback completes',$('hint').textContent==='Great brushing!');
 check('Brushing does not skip page',$('counter').textContent==='6 / 9');
 click('next');
 [...$('choices').children].forEach(b=>b.click());
 check('Three surfaces all checked',[...$('choices').children].every(b=>b.getAttribute('aria-pressed')==='true'));
 check('Diagram highlight follows tops',!$('highlight').hidden&&$('highlight').style.top==='73%');
 click('next');[...$('choices').children].forEach(b=>b.click());
 check('Morning and night both checked',!$('sunTick').hidden&&!$('moonTick').hidden);
 check('Routine feedback',$('hint').textContent==='Morning AND night!');
 click('previous');click('next');
 check('Interaction state retained on return',[...$('choices').children].every(b=>b.getAttribute('aria-pressed')==='true'));
 click('next');click('tap');check('Celebration feedback',$('hint').textContent==='Hooray for brushing!');
 check('Final page offers read again',$('next').textContent==='Read again ↺');
 click('next');check('Read again returns to cover',$('counter').textContent==='1 / 9');
 for(let i=0;i<7;i++)click('next');
 check('Read again resets routine',[...$('choices').children].every(b=>b.getAttribute('aria-pressed')==='false'));
 if('speechSynthesis' in window){
   let spoken='',cancelled=0;
   const realSpeak=window.speechSynthesis.speak.bind(window.speechSynthesis),realCancel=window.speechSynthesis.cancel.bind(window.speechSynthesis);
   window.speechSynthesis.speak=u=>{spoken=u.text;};
   window.speechSynthesis.cancel=()=>{cancelled++;};
   click('read');check('Read aloud receives current story sentence',spoken==='Morning and night.');
   click('next');check('Turning page cancels speech',cancelled>0&&$('read').textContent==='♪ Read aloud');
   window.speechSynthesis.speak=realSpeak;window.speechSynthesis.cancel=realCancel;
 }
 click('restart');
 return {checks,total:checks.length,passed:checks.filter(x=>x.pass).length};
})();
